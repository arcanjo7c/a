# Barbearia Alex – configuração

Arquivos: `index.html` (clientes), `admin.html` (barbeiro), `schema.sql` (banco).

1. **Banco:** crie um projeto grátis em supabase.com. Em *SQL Editor*, cole e rode o `schema.sql`.
2. **Acesso do barbeiro:** *Authentication > Users > Add user*, com e-mail e senha do Alex (marque "Auto Confirm User"). Depois, no SQL Editor, rode a última linha do `schema.sql` (a do `insert into public.barbeiros`) com o e-mail dele.
3. **Segurança:** em *Authentication > Sign In / Providers*, desligue "Allow new users to sign up". Assim ninguém além do Alex cria conta.
4. **Chaves:** em *Settings > API*, copie a *Project URL* e a chave *anon public*. Cole nas duas linhas `SUPABASE_URL` e `SUPABASE_ANON_KEY` no topo do script do `index.html` e do `admin.html`. Nunca use a chave `service_role`.
5. **Publicar:** envie a pasta para Netlify (arrastar a pasta em app.netlify.com/drop), Vercel ou GitHub Pages. Depois, em *Authentication > URL Configuration*, ponha o endereço do site em *Site URL*.
6. **Testar:** faça um agendamento em `/`, entre em `/admin.html` com o login do Alex e confira que ele aparece. Tente marcar o mesmo horário de outro aparelho: deve ser recusado.

Preços e serviços ficam na tabela `servicos` (e na lista `SERVICES` do `index.html`, que precisa ter os mesmos nomes).
